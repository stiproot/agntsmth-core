# agnt-smth

A simple agentic workflow builder framework, ontop of LangChain and LangGraph.